﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Previred.DesafioUno
{
    class Program
    {
        /// <summary>
        /// Previred - Desafío Uno
        /// Autor: Michaelle Arias
        /// Descripción: Aplicación de consola que recibe un archivo json con fechas en un rango determinado 
        /// y que devuelve otro archivo con las fechas faltantes de ese rango.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Obteniendo parámetros...");
                if (args.Length < 2)
                {
                    Console.WriteLine("Debe ingresar ambos parámetros (rutas de archivos de entrada y salida).");
                    return;
                }

                FileInfo fiJsonEntrada = new FileInfo(args[0]);
                FileInfo fiJsonSalida = new FileInfo(args[1]);

                Console.WriteLine("Procesando Archivo de entrada...");
                if (!fiJsonEntrada.Exists)
                {
                    Console.WriteLine("Archivo de entrada \"{0}\" no existe o no está disponible.", args[0]);
                    return;
                }

                JavaScriptSerializer jss = new JavaScriptSerializer(){ MaxJsonLength = Int32.MaxValue };
                Dictionary<string, object> dicSalida = null;

                try
                {
                    Dictionary<string, object> dicEntrada = jss.Deserialize<Dictionary<string, object>>(File.ReadAllText(fiJsonEntrada.FullName));
                    DateTime fechaCreacion = Convert.ToDateTime(dicEntrada["fechaCreacion"].ToString(), new CultureInfo("en-US"));
                    DateTime fechaFin = Convert.ToDateTime(dicEntrada["fechaFin"].ToString(), new CultureInfo("en-US"));
                    List<DateTime> lstFechas = (dicEntrada["fechas"] as ArrayList).Cast<string>()
                        .Select(fecha => Convert.ToDateTime(fecha, new CultureInfo("en-US"))).ToList();
                    List<DateTime> lstFechasFaltantes = new List<DateTime>();
                    while (fechaCreacion <= fechaFin)
                    {
                        if (!lstFechas.Contains(fechaCreacion))
                            lstFechasFaltantes.Add(fechaCreacion);
                        fechaCreacion = fechaCreacion.AddMonths(1);
                    }
                    List<string> lstFechasFaltantesStr = lstFechasFaltantes
                        .Select(fecha => fecha.ToString("yyyy-MM-dd")).ToList();

                    Console.WriteLine("Generando Archivo de salida...");

                    dicSalida = new Dictionary<string, object>
                    {
                        { "id", dicEntrada["id"] },
                        { "fechaCreacion", dicEntrada["fechaCreacion"] },
                        { "fechaFin", dicEntrada["fechaFin"] },
                        { "fechasFaltantes", lstFechasFaltantesStr }
                    };
                }
                catch(Exception exJss)
                {
                    Console.WriteLine("Archivo de entrada \"{0}\" no es un archivo JSON válido o no tiene la estructura esperada.", args[0]);
                    return;
                }

                if (dicSalida != null)
                {
                    string dicSalidaStr = jss.Serialize(dicSalida);
                    //"formateo"...
                    dicSalidaStr = new Utiles.JsonFormatter(dicSalidaStr).Format();                        

                    File.WriteAllText(fiJsonSalida.FullName, dicSalidaStr);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Hubo errores al ejecutar el Desafío Uno: {0}.", ex.Message);
            }
            finally
            {
                Console.WriteLine("Proceso finalizado, presione cualquier tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}
