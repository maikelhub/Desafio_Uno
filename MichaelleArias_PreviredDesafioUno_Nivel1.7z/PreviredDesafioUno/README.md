﻿Instrucciones:

Esta aplicación se debe compilar con Visual Studio 2019, el framework es la versión 4.7.2.
Para ejecutar las pruebas se deben pasar los nombres de los archivos de entrada (archivo origen JSON con fechas) 
y de salida (archivo destino JSON con fechas faltantes).

Se debe abrir una ventana de comandos en la ruta "bin/Debug" del projecto y ejecutar como indica el siguiente ejemplo:
PreviredDesafioUno.exe "c:\archivoFechas.json" "c:\archivosFechasFaltantes.json"

Nota: La aplicación contiene las validaciones básicas en el paso de parámetros, rutas y formatos de archivos.

Saludos.
